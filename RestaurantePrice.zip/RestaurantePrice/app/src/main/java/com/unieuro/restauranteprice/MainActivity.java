package com.unieuro.restauranteprice;

import android.app.Activity;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button b1 = (Button) findViewById(R.id.BtnCalcular);
        final EditText consumo = (EditText) findViewById(R.id.edt_consumo);
        final EditText couver_artitisco = (EditText) findViewById(R.id.edt_couver_artistico);
        final EditText dividir = (EditText) findViewById(R.id.edt_dividir);
        final EditText servico = (EditText) findViewById(R.id.edt_servico);
        final EditText Ctotal = (EditText) findViewById(R.id.edt_conta_total);
        final EditText Cpessoa = (EditText) findViewById(R.id.edt_valor_pessoa);

        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Double consum = Double.parseDouble(consumo.getText().toString());
                Double serv = consum * 0.10;
                servico.setText("" + serv);

                Double couver = Double.parseDouble(couver_artitisco.getText().toString());
                Double contatotal = serv + consum + couver;
                Ctotal.setText("" + contatotal);

                Double Dpessoa = Double.parseDouble(Cpessoa.getText().toString());
                Double Divp = contatotal / Dpessoa;
                Cpessoa.setText("" + Divp);

            }
        });

    }
}
