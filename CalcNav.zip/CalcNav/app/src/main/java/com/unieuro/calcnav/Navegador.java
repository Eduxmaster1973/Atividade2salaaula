package com.unieuro.calcnav;

import android.app.Activity;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class Navegador extends Activity {

    private Button btUrl;
    private EditText enderecoUrl;
    private WebView navWeb;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_navegador);

        btUrl = (Button) findViewById(R.id.btSearch);
        enderecoUrl = (EditText)findViewById(R.id.textoUrl);
        navWeb = (WebView)findViewById(R.id.webSite);

        navWeb.setWebViewClient(new WebViewClient());

        btUrl.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                navWeb.loadUrl(enderecoUrl.getText().toString());
            }
        });
    }
}
