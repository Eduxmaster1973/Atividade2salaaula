package com.unieuro.calcnav;

import android.app.Activity;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class Calculadora extends Activity {

    EditText ed_val1,ed_val2, ed_result;
    Button bt_soma, btsub, btmult,btdiv,btporcent, btpotencia;
    double v1,v2,resultado;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_calculadora);

        final EditText ed_val1 = (EditText) findViewById(R.id.ed_val1);
        final EditText ed_val2 = (EditText) findViewById(R. id.ed_val2);
        final EditText result = (EditText) findViewById(R.id.ed_result);


        Button bt_soma = (Button) findViewById(R.id.bt_soma);
        Button btsub = (Button) findViewById(R.id.btsub);
        Button btmult = (Button) findViewById(R.id.btmult);
        Button btdiv = (Button) findViewById(R.id.btdiv);
        Button btporcent = (Button) findViewById(R.id.btporcent);
        Button btpotencia = (Button) findViewById(R.id.btpotencia);


        bt_soma.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Double v1 = Double.parseDouble(ed_val1.getText().toString());
                Double v2= Double.parseDouble(ed_val2.getText().toString());

                resultado = v1+v2;
                result.setText(String.valueOf(resultado));
            }
        });

        btsub.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Double v1 = Double.parseDouble(ed_val1.getText().toString());
                Double v2= Double.parseDouble(ed_val2.getText().toString());

                resultado = v1-v2;
                result.setText(String.valueOf(resultado));
            }
        });

        btmult.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Double v1 = Double.parseDouble(ed_val1.getText().toString());
                Double v2= Double.parseDouble(ed_val2.getText().toString());

                resultado = v1*v2;
                result.setText(String.valueOf(resultado));
            }
        });

        btdiv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Double v1 = Double.parseDouble(ed_val1.getText().toString());
                Double v2= Double.parseDouble(ed_val2.getText().toString());

                resultado = v1/v2;
                result.setText(String.valueOf(resultado));
            }
        });

        btporcent.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Double v1 = Double.parseDouble(ed_val1.getText().toString());
                Double v2= Double.parseDouble(ed_val2.getText().toString());

                resultado = (v1*v2)/100;
                result.setText(String.valueOf(resultado));
            }
        });

        btpotencia.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Double v1 = Double.parseDouble(ed_val1.getText().toString());

                resultado = (v1*v1);
                result.setText(String.valueOf(resultado));
            }
        });
    }
}
